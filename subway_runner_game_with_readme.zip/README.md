
# Subway Surfers Style Runner Game (Clone)

A simple endless runner game inspired by Subway Surfers. Built using HTML, CSS, and JavaScript, this game runs entirely in the browser and can be played online for free.

🎮 Features:
- Endless scrolling background
- Character jump and dodge mechanics
- Basic collision detection
- Increasing difficulty over time

🕹️ Play the game online or clone the repo and run it locally.

🚀 Live Demo: https://nayannaman33.github.io/subway-runner-clone/
